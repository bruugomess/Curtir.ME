var searchData=
[
  ['salvapostagem_0',['salvaPostagem',['../classmanipulador_de_postagem.html#addcb690272f5cd3089d780512f0e60be',1,'manipuladorDePostagem']]],
  ['salvarusuario_1',['salvarUsuario',['../classmanipulador_de_usuario.html#adfdc9c0b787e8b07be558547676e5ea5',1,'manipuladorDeUsuario']]],
  ['segue_2',['segue',['../classmanipulador_de_usuario.html#ad71cce3927890dd811f80cfa607534a7',1,'manipuladorDeUsuario']]],
  ['seguir_3',['seguir',['../classmanipulador_de_usuario.html#a21a63af655a088fb028c1dd76c97b712',1,'manipuladorDeUsuario::seguir(int idSeguidor, int idSeguido)'],['../classmanipulador_de_usuario.html#ae98ff083f698771e3c217df4499158e5',1,'manipuladorDeUsuario::seguir(int idSeguidor, char *nomeSeguidor)']]],
  ['setapagada_4',['Setapagada',['../class_postagem.html#a5c6c311a564bcce58f63868ce5e423c7',1,'Postagem']]],
  ['setconteudo_5',['setconteudo',['../class_comentario.html#a92da948ecdb87b84df8706fd308fa2b4',1,'Comentario::Setconteudo()'],['../class_postagem.html#a2f7f760fb86a60d2e4824b391d6a308b',1,'Postagem::Setconteudo(string conteudo)']]],
  ['setcurtidas_6',['Setcurtidas',['../class_postagem.html#ab95513d9f4f40c71fffbccc669f7f8ab',1,'Postagem']]],
  ['setexiste_7',['Setexiste',['../class_hashtag.html#a4cf910f67229fc50d0de59f0d36e2f54',1,'Hashtag']]],
  ['sethashtag_8',['Sethashtag',['../class_hashtag.html#a09755d2868acf43fb3d797d80d5599d9',1,'Hashtag']]],
  ['setid_9',['setId',['../class_usuario.html#af194ae382c089232b5d91bf5c93eee09',1,'Usuario']]],
  ['setidpostagem_10',['SetIDpostagem',['../class_comentario.html#a6fca6bffa5669d41bf90a01b66f6a00a',1,'Comentario']]],
  ['setidusuario_11',['setidusuario',['../class_comentario.html#a72636eb34e110736a9174e91eb962bc9',1,'Comentario::SetIDusuario()'],['../class_postagem.html#a56b8e07c9090c5a5b7ab9e186d57cdf5',1,'Postagem::SetIDusuario()']]],
  ['setnome_12',['setNome',['../class_usuario.html#a7c9b128fcb7b02e6595200ad1cf6f89b',1,'Usuario']]],
  ['setnomeusuario_13',['SetnomeUsuario',['../class_comentario.html#ac519efc73bd3a461cb95447df86336ec',1,'Comentario']]],
  ['setnumerocomentario_14',['SetnumeroComentario',['../class_comentario.html#a5e03c4fe78ce3edaf9f7f7dbe12bfc45',1,'Comentario']]],
  ['setnumeropostagem_15',['SetnumeroPostagem',['../class_postagem.html#a6f99e664af4d9777bbbb6a869d45e309',1,'Postagem']]],
  ['setsenha_16',['setSenha',['../class_usuario.html#ad6ca0fc126212f12a73e7e8536646d60',1,'Usuario']]]
];
