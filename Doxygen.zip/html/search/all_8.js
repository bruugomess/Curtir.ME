var searchData=
[
  ['manipuladordearquivo_0',['manipuladorDeArquivo',['../classmanipulador_de_arquivo.html',1,'']]],
  ['manipuladordecomentario_1',['manipuladorDeComentario',['../classmanipulador_de_comentario.html',1,'']]],
  ['manipuladordepostagem_2',['manipuladorDePostagem',['../classmanipulador_de_postagem.html',1,'']]],
  ['manipuladordeusuario_3',['manipuladorDeUsuario',['../classmanipulador_de_usuario.html',1,'']]],
  ['mostrarfeed_4',['mostrarFeed',['../classmanipulador_de_postagem.html#a60a90cf95d17eb5e1dc973762e789852',1,'manipuladorDePostagem']]],
  ['mostrarfeeddosseguidos_5',['mostrarFeedDosSeguidos',['../classmanipulador_de_postagem.html#abdf8f07afa03978178b934d48ab81927',1,'manipuladorDePostagem']]],
  ['mostrarfeedporhashtag_6',['mostrarFeedPorHashtag',['../classmanipulador_de_postagem.html#ac11fde05e68b48e27700632a493455c1',1,'manipuladorDePostagem']]]
];
