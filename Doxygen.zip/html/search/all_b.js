var searchData=
[
  ['retiradearquivodeinteiros_0',['retiraDeArquivoDeInteiros',['../classmanipulador_de_usuario.html#aef6e8ca904903cd3db4f05c3f78a5c22',1,'manipuladorDeUsuario']]]
];
