var searchData=
[
  ['zeraarquivo_0',['zeraArquivo',['../classmanipulador_de_arquivo.html#a90f211e8828322a8564f4acc322ebe99',1,'manipuladorDeArquivo']]]
];
