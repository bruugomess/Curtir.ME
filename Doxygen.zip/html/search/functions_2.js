var searchData=
[
  ['cadastrarusuario_0',['cadastrarUsuario',['../classmanipulador_de_usuario.html#a8b5a0d1ceb63d75007f8b78f360484d8',1,'manipuladorDeUsuario']]],
  ['comentario_1',['comentario',['../class_comentario.html#a823628aef9bb117bd63e93d97c2448e9',1,'Comentario::Comentario(int ID, char nomeUsuario[], int IDpostagem, int numeroC, char conteudo[])'],['../class_comentario.html#a8a571b14727894df864f75114603ca12',1,'Comentario::Comentario()']]],
  ['copiararquivo_2',['copiarArquivo',['../classmanipulador_de_arquivo.html#a2724bdd0f18cb5c9b061c892a004f156',1,'manipuladorDeArquivo']]],
  ['criaarquivosnescessarios_3',['criaarquivosnescessarios',['../class_hashtag.html#afe65ddf6f4400bb38996fd289b2c6367',1,'Hashtag::criaArquivosNescessarios()'],['../classmanipulador_de_comentario.html#a3819da1dd317dcb19f9c09eb6787504e',1,'manipuladorDeComentario::criaArquivosNescessarios()'],['../classmanipulador_de_postagem.html#a108bedd778ebe8c91e996df3fdb1706c',1,'manipuladorDePostagem::criaArquivosNescessarios()'],['../classmanipulador_de_usuario.html#a8920ddad355dacd6b8f733d54696a3f9',1,'manipuladorDeUsuario::criaArquivosNescessarios()']]]
];
