var searchData=
[
  ['numerodepostagens_0',['numeroDePostagens',['../classmanipulador_de_postagem.html#a0410185f10f0f23411241baaeb3e05fd',1,'manipuladorDePostagem']]],
  ['numerodeusuarios_1',['numeroDeUsuarios',['../classmanipulador_de_usuario.html#ab54c901ff318fc9e684f35e049148fb0',1,'manipuladorDeUsuario']]],
  ['numeroseguidores_2',['numeroSeguidores',['../class_usuario.html#a8814da32d12466ce0973a7c8a4550f8a',1,'Usuario']]],
  ['numeroseguindo_3',['numeroSeguindo',['../class_usuario.html#a0f38cc51bcb7ce502ed7a97266d657b1',1,'Usuario']]]
];
