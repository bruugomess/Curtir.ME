var searchData=
[
  ['usuario_0',['usuario',['../class_usuario.html#aa85a5371a098dfba5449140d9b8a472f',1,'Usuario::Usuario()'],['../class_usuario.html#a0e04d4e08cd61c34babe4a86afd01304',1,'Usuario::Usuario(char nome[], char senha[], int id)']]]
];
