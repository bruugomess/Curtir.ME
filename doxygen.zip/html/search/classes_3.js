var searchData=
[
  ['postagem_0',['Postagem',['../class_postagem.html',1,'']]]
];
