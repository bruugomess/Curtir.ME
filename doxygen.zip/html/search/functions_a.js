var searchData=
[
  ['postagem_0',['postagem',['../class_postagem.html#a0ce2e2d19d707a67d53d5c0c648a1467',1,'Postagem::Postagem(int ID, int numeroP, char conteudo[])'],['../class_postagem.html#ab70d7af09da7441324472991c4daff88',1,'Postagem::Postagem()']]],
  ['printacomentario_1',['printaComentario',['../classmanipulador_de_comentario.html#adb4f4675386bb9cb65ad52c6e4efc3af',1,'manipuladorDeComentario']]],
  ['printamenu_2',['printaMenu',['../_main_8cpp.html#aae5ff2eaea8eaee2821db0c97ed09f0b',1,'Main.cpp']]],
  ['printamenufeed_3',['printaMenuFeed',['../_main_8cpp.html#a188451490c8ad5725ff5badf2411a48c',1,'Main.cpp']]],
  ['printamenufeedpostagens_4',['printaMenuFeedPostagens',['../_main_8cpp.html#aff37d36312191fd1ec16b5b65ca1d5a7',1,'Main.cpp']]],
  ['printamenulogin_5',['printaMenuLogin',['../_main_8cpp.html#a20e132528957209d874c2683b0e2eff1',1,'Main.cpp']]],
  ['printamenupostagens_6',['printaMenuPostagens',['../_main_8cpp.html#a07fccab2ab10b28b3ae8e4460caf428e',1,'Main.cpp']]],
  ['procurausuarioid_7',['procuraUsuarioId',['../classmanipulador_de_usuario.html#a704fb599e9094dc4820cb1a11d845bab',1,'manipuladorDeUsuario']]],
  ['procurausuarionome_8',['procuraUsuarioNome',['../classmanipulador_de_usuario.html#a7d1cf70176030c2d432837cf003c3a49',1,'manipuladorDeUsuario']]]
];
