var searchData=
[
  ['numerodepostagens_0',['numeroDePostagens',['../classmanipulador_de_postagem.html#a0410185f10f0f23411241baaeb3e05fd',1,'manipuladorDePostagem']]],
  ['numerodeusuarios_1',['numeroDeUsuarios',['../classmanipulador_de_usuario.html#ab54c901ff318fc9e684f35e049148fb0',1,'manipuladorDeUsuario']]]
];
