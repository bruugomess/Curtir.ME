var searchData=
[
  ['geraexcecao_0',['geraExcecao',['../classmanipulador_de_arquivo.html#a3413f7f31933b14a3783f604b26b823b',1,'manipuladorDeArquivo']]],
  ['getapagada_1',['Getapagada',['../class_postagem.html#a87291a6e8147298f7baf8cc060029bb1',1,'Postagem']]],
  ['getconteudo_2',['getconteudo',['../class_comentario.html#ad99fe500e645b7d3b47030d7c429e9e9',1,'Comentario::Getconteudo()'],['../class_postagem.html#a762f4e8509edf7f0d6fcccc0e0595465',1,'Postagem::Getconteudo()']]],
  ['getcurtidas_3',['Getcurtidas',['../class_postagem.html#a50a506368f6a084698cdc2c488060b2d',1,'Postagem']]],
  ['getexiste_4',['Getexiste',['../class_hashtag.html#a22121aed254cf58ab3352b3358ed5522',1,'Hashtag']]],
  ['gethashtag_5',['Gethashtag',['../class_hashtag.html#a7c1a7798bb498e20055f9a1fab1f0e41',1,'Hashtag']]],
  ['getid_6',['getId',['../class_usuario.html#a654c2014a73c6361cbcf40af60098229',1,'Usuario']]],
  ['getidpostagem_7',['GetIDpostagem',['../class_comentario.html#aadea39e075d5a7bde5452e28cdae6d03',1,'Comentario']]],
  ['getidusuario_8',['getidusuario',['../class_comentario.html#ab3837e36f32ab91c33d9e1b3b0056da4',1,'Comentario::GetIDusuario()'],['../class_postagem.html#a47c1c07737a698e43d0b17817c702ce7',1,'Postagem::GetIDusuario()']]],
  ['getnome_9',['getNome',['../class_usuario.html#a02aaf942c16311ce55c1a01f3bce752a',1,'Usuario']]],
  ['getnomeusuario_10',['GetnomeUsuario',['../class_comentario.html#af1a320c75084b56ccf6eee0474bec737',1,'Comentario']]],
  ['getnumerocomentario_11',['GetnumeroComentario',['../class_comentario.html#a684e92abc86a0b6651ca94197d63a45c',1,'Comentario']]],
  ['getnumeropostagem_12',['GetnumeroPostagem',['../class_postagem.html#a678a15a9b3a593d1858cd19897528828',1,'Postagem']]],
  ['getsenha_13',['getSenha',['../class_usuario.html#adcd27797118885603165d41044d8de59',1,'Usuario']]]
];
