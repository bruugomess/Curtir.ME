var searchData=
[
  ['hashtag_0',['hashtag',['../class_postagem.html#a29cec0a5a96014ea6c2553d9086b8663',1,'Postagem']]]
];
