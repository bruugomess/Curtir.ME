var searchData=
[
  ['manipuladorcomentarios_0',['manipuladorComentarios',['../_main_8cpp.html#ad241aa90e25cdd5bfc0e214787143798',1,'Main.cpp']]],
  ['manipuladorhashtag_1',['manipuladorHashtag',['../_main_8cpp.html#a69df3a6cb512dbec1e130af14bde122e',1,'Main.cpp']]],
  ['manipuladorpostagens_2',['manipuladorPostagens',['../_main_8cpp.html#aacb8a2f7e41ffcda1e02692ddfee1bc3',1,'Main.cpp']]],
  ['manipuladorusuarios_3',['manipuladorUsuarios',['../_main_8cpp.html#a782ac13b4190510c41eea9f935df756d',1,'Main.cpp']]]
];
