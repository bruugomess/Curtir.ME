var searchData=
[
  ['manipuladordearquivo_0',['manipuladorDeArquivo',['../classmanipulador_de_arquivo.html',1,'']]],
  ['manipuladordecomentario_1',['manipuladorDeComentario',['../classmanipulador_de_comentario.html',1,'']]],
  ['manipuladordepostagem_2',['manipuladorDePostagem',['../classmanipulador_de_postagem.html',1,'']]],
  ['manipuladordeusuario_3',['manipuladorDeUsuario',['../classmanipulador_de_usuario.html',1,'']]]
];
