var searchData=
[
  ['numeroseguidores_0',['numeroSeguidores',['../class_usuario.html#a8814da32d12466ce0973a7c8a4550f8a',1,'Usuario']]],
  ['numeroseguindo_1',['numeroSeguindo',['../class_usuario.html#a0f38cc51bcb7ce502ed7a97266d657b1',1,'Usuario']]]
];
