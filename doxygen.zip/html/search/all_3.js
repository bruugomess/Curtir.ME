var searchData=
[
  ['deixardeseguir_0',['deixardeseguir',['../classmanipulador_de_usuario.html#a7eb5829060a8e1c897b16047049f539f',1,'manipuladorDeUsuario::deixarDeSeguir(int idSeguidor, int idSeguido)'],['../classmanipulador_de_usuario.html#a94fc9474d40ebc0ea336bf74281258ed',1,'manipuladorDeUsuario::deixarDeSeguir(int idSeguidor, char nomeSeguido[])']]],
  ['detalhar_1',['detalhar',['../classmanipulador_de_postagem.html#a411a0eaa185fe07e536817e409b68e62',1,'manipuladorDePostagem']]]
];
