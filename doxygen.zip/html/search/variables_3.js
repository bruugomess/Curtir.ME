var searchData=
[
  ['usuarioatual_0',['usuarioAtual',['../manipulador_de_usuario_8h.html#abc48cbf4b0386be5026734f0ce9cf0dd',1,'manipuladorDeUsuario.h']]]
];
