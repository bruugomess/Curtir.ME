var searchData=
[
  ['sucesso_0',['sucesso',['../_main_8cpp.html#aaaedc86bb131eb3857bb8a498b897037',1,'Main.cpp']]]
];
