var searchData=
[
  ['ehminhapostagem_0',['ehMinhaPostagem',['../classmanipulador_de_postagem.html#a501d9537ec01644bf2c86a6e78efbfd1',1,'manipuladorDePostagem']]],
  ['exibircomentariosporid_1',['exibirComentariosPorId',['../classmanipulador_de_comentario.html#af7b6ec3c24b2ac15e67ffb94d3c8417a',1,'manipuladorDeComentario']]],
  ['existe_2',['existe',['../class_comentario.html#a68ed788e969fd95fb248a0a8f6cc873f',1,'Comentario::existe()'],['../class_postagem.html#ab55c0820ea849c9164e8ee03865146df',1,'Postagem::existe()'],['../class_usuario.html#acbe052c8005fa5c88b4015603af8e5dd',1,'Usuario::existe()']]]
];
